<?php
    //  getting all values from the HTML form
    if(isset ($_POST['submit'])) {
        $fullName = $_POST['fullName'];
        $phoneNumber = $_POST['phoneNumber'];
        $email = $_POST['email'];
        $location = $_POST['location'];
        $productNumber = $_POST['productNumber'];
        
    }

    //  database details
    $host = "localhost";
    $username = "root";
    $password = "";
    $dbname = "murphy_db";

    //  creating a connection
    $con = mysqli_connect($host, $username, $password, $dbname);

    //  to ensure that the connection is made
    if(!$con) {
        die("Connection failed!" . mysqli_connect_error());
    }

    //  send query to the database to add values and confirm if successful
    $sql = "INSERT INTO user(id, fullName, phoneNumber, email, location, productNumber)
        VALUES ('0', '$fullName', '$phoneNumber', '$email', '$location', '$productNumber')";

    $rs = mysqli_query($con, $sql);
    if($rs) {
        header("location:successfulpage.html");
       // echo "Entries added!";
    }

    //  close connection
    mysqli_close($con);